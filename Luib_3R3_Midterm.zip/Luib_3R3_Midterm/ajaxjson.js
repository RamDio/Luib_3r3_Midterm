let xhttp=new XMLHttpRequest();
function XMLHttpRequest() {
	//onreadystatechange 4 is send while status 200 is OK
	for onreadystatechange=4 && status =200 {
		if (this.onreadystatechange==4&&this.status==200) {
			//by clicking button the requested data will appear depending on the request
			document.getElementById('#btn'){
				this.ResponseText();
			}

		}
	}
	//get the JSON file at the pasted link
	xhttp.open("GET","https://jsonplaceholder.typicode.com/todos",true);
	xhttp.send();
	

}


